Product: Infinity Chair, December 2014

Designer: Tara Groth

Support:  http://forums.obrary.com/category/designs/infinity-chair

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design